%tHis script attempts to solve number 1 from the ENSC 180 assignment 7
%martin Yang
%MArch 26, 2018

M = [0 2 0; 8 0 3; 0 0 5];
V = 3:4:133;

%pArt a
A = M + 3*(M > 0 & M < 5)

%part B
B = V + 2*(mod(V,7) == 0)

%Part C
%THis solution ONLY works for the case of the vector V, which is always
%less than 777 and 133(the max value in V), so the third digit can be ignored and only the first two
%digits can be considered.
C_SecDig = fix(V/10);
C_FirDig = V-C_SecDig*10;
C = V.*(C_SecDig == 7 | C_FirDig == 7);
C(C==0) = []
%Removes all zeros and shrinks vector

%PArt D
V21 = input('Enter the first number of the vector');
V22 = input('Enter the second number of the vector');

%Initializing equally spaced numbers for a total of 30 terms
V2temp = V21:(V22-V21):30*(V22-V21);
D_oddIndex = 1:2:length(V2temp);
D_evenIndex = 2:2:length(V2temp);

D_odds = V2temp(D_oddIndex);
D_evens = V2temp(D_evenIndex);
V2 = D_odds+D_evens