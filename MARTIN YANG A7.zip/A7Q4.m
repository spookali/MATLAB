%This script will solve Q4 of A7 Ensc 180
%martin Yang
%Apr 2

syms t
x = 805:20:985;
y = [0.710 0.763 0.907 1.336 2.169 1.598 0.916 0.672 0.615 0.606];
x1 = 805:985;
y1 = interp1(x,y,x1,'spline');
p = polyfit(x,y,9);
hold on
plot(x,y,'bo')
p1 = polyval(p,x);
p1sym = poly2sym(p,t);
plot(x,p1,'k')
fplot(p1sym,'r')
xlim([805,985])
ylim([0,3])
xlabel('x')
ylabel('y')
title('Graph of plots, spline interpolation, and polyfit vs x')
legend('Data Points','Spline Curve','Polyfit')