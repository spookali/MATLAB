%This script will attempt to solve question 3 of ENSC 180 Assignment 7
%Martin Yang
%Apr 2- 2018

syms x
y = (2*x^4-x^2+x-1)/(x^2-2);
dy = simplify(diff(y,x));
d2y = simplify(diff(dy,x));
d3y = simplify(diff(d2y,x)); %for minima maxima
d4y = simplify(diff(d3y,x)); %for infletion

%for solving minima and maxima
eqn1 = dy == 0;
eqn2 = d2y == 0;
eqn3 = d3y == 0;
eqn4 = d4y == 0;

%to separate out numerators and denominators to find asymptote lines
[num1,den1] = numden(y);
[num2,den2] = numden(dy);
[num3,den3] = numden(d2y);

%Finding asymptote points
asymp1 = solve(den1 == 0, x, 'Real', true);
%asymp2 = solve(den2 == 0, x, 'Real', true);
%asymp3 = solve(den3 == 0, x, 'Real', true);
%Upon inspection, the denominator changes but the roots of the denominator
%polynomial only increases in multiplicities, meaning the asynptote does
%not change for every derivative


extrema1temp = solve(eqn1, x, 'Real', true);
extrema2temp = solve(eqn2, x, 'Real', true);
extrema3temp = solve(eqn3, x, 'Real', true);
extrema4temp = solve(eqn4, x, 'Real', true);

extrema1 = vpa(extrema1temp, 6);
extrema2 = vpa(extrema2temp, 6);
extrema3 = vpa(extrema3temp, 6);
extrema4 = vpa(extrema4temp, 6);

%Plots are below, they are in order of convenience of the legend as
%multiples of the same legend entry appeared

fplot(y)
hold on
fplot(x,dy)
fplot(x,d3y)

for i = 1:length(extrema2) %Dy
    if subs(d3y, extrema2(i)) > 0
        plot(extrema2(i), subs(dy, extrema2(i)), 'bo');
    else
        plot(extrema2(i), subs(dy, extrema2(i)), 'ro');
    end
end


plot(extrema2, subs(y,extrema2), 'g*') %inflection point plot
plot(asymp1, 0, 'kx')



plot(extrema4, subs(dy, extrema4), 'g*') %inflection point


for i = 1:length(extrema1) %y
    if subs(d2y, extrema1(i)) > 0
        plot(extrema1(i), subs(y,extrema1(i)), 'bo');
    else
        plot(extrema1(i), subs(y,extrema1(i)), 'ro');
    end
end

for i = 1:length(extrema3) %D2y
    if subs(d3y, extrema3(i)) > 0
        plot(extrema3(i), subs(dy, extrema3(i)), 'bo');
    else
        plot(extrema3(i), subs(dy, extrema3(i)), 'ro');
    end
end



plot(extrema3, subs(dy, extrema3), 'g*') %inflection point
ylim([-200,200])
xlim([-3,3])
title('Graph of y vs x')
xlabel('x')
ylabel('y')
legend('y','Dy','D2y','Minima','Maxima','Inflection Point','Asymptote Line')