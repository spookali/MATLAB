%This script will attempt to solve question #6 ENSC 180 A #7
%Martin Yang
%Apr 2 2018
%The ODE is embedded in the A7Q6f.m file
%I could not figure out how to pass a variable into the ODE function file
%so I simply added the constants in the .m file manually

[t,y] = ode45('A7Q6f',[0 20], [0 0]);
figure
plot(t,y(:,1))
xlabel('t')
ylabel('y')
ylim auto
xlim auto
title('Graph of Position vs. Time of a mass on a spring')