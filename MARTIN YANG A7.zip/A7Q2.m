%This script will attempt to solve question #2 of assignment 7 ENSC 180
%Martin Yang
%Apr 1, 8102

%time
t = 0:7200; %2 hours in seconds

I = 8.4;                %Current in A
r = 0.002;             %Radius in m
p = 2.6989*1000*1000;              %Density in g/L
mp = (660.37+273.15);        %Melting Point in K
Res = 0.0000265548/1000; %Resistivity NOT Resistance!!!!! first number is mOhm-cm converted to Ohm-cm by /1000
L = 5;              %Length in m
A = pi*r*r;         %Cross sectional area  of wire
R = Res*L/A;        %Resistance
T0 = (20+273.15);            %Initial temperature
C = (0.215*4184);           %Specific Heat capacity in J/g K
V = A*L;            %Volume
m = V*p;            %Mass of wire

Power = I*I*R;
Energy = Power*t;
dT = Energy/(m*C);
T = T0 + dT;

%Part a, Plotting temperature profile
plot(t,T)
xlabel('Time t (s)')
ylabel('Temperature T (C)')
title('Graph of Temperature vs Time of a Wire with constant Current')


%Part B, determining whether wire reaches melting point temperature within
%the initial conditions and 2 hours
MeltingPointPoint = find(T>=mp,1); %First argument is the condition to find, the second argument specifies that only the first and only 1 index is required
if MeltingPointPoint ~= 0
    fprintf('The wire has reached the melting point within the two hours at %i seconds \n', t(MeltingPointPoint))
else
    fprintf('The wire has not reached the melting point within the two hours of operaation \n')
end

%Part C, determining the maximum current for which the wire will not melt
%within the two hours
slope = (mp-0.01 - T0)/7200; %The 0.01 is so that at the end of the two hours, the temperature will not be exactly the melting point
%dT = I*I*R*t/(m*C), where dT acts as the slope parameter and solving for I
%gives sqrt(dT m C / (R t))
Imax = sqrt(slope*m*C/(R));
fprintf('The maximum current at which the wire will not reach the melting point within two hours is %fA \n', Imax)