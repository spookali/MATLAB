function ydot=A7Q6f(t,y)
ydot(1)=y(2);
ydot(2)=(10*sin(10*t)-75*y(1))/3;
ydot=ydot';
end