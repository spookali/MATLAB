%This script will attempt to solve Q5 of Assignment 7 Ensc 180
%martin yaang
%Apr 3, 2018
syms t
x = [0 0.005 0.0075 0.0125 0.025 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
yu = [0 0.0102 0.0134 0.017 0.025 0.0376 0.0563 0.0812 0.0962 0.1035 0.1033 0.095 0.0802 0.0597 0.034 0];
yl = [0 -0.0052 -0.0064 -0.0063 -0.0064 -0.006 -0.0045 -0.0016 0.001 0.0036 0.007 0.0121 0.017 0.01999 0.0178 0];
x1 = 0:0.001:1;

yu1 = interp1(x,yu,x1,'spline');
yl1 = interp1(x,yl,x1,'spline');
hold on
%plot(x,yu)
%plot(x,yl)
title('Spline Graph')
xlabel('x')
ylabel('y')
plot(x1,yu1,'r')
plot(x1,yl1,'g')
xlim([0,1])
ylim([-0.05 0.15])

pu1 = polyfit(x,yu,4); %4th degree fit
pl1 = polyfit(x,yl,4);
pu2 = polyfit(x,yu,8); %8th degree fit
pl2 = polyfit(x,yl,8);
pu3 = polyfit(x,yu,12); %12th degree fit
pl3 = polyfit(x,yl,12);
pu4 = polyfit(x,yu,15); %15th degree fit   why warnings of badly cconditioned?
pl4 = polyfit(x,yl,15);

pu_1 = polyval(pu1,x);
pl_1 = polyval(pl1,x);
pu_2 = polyval(pu2,x);
pl_2 = polyval(pl2,x);
pu_3 = polyval(pu3,x);
pl_3 = polyval(pl3,x);
pu_4 = polyval(pu4,x);
pl_4 = polyval(pl4,x);

figure
hold on
title('4th Degree Polyfit')
xlabel('x')
ylabel('y')
xlim([0,1])
ylim([-0.05 0.15])
plot(x,pu_1)
plot(x,pl_1)

figure
hold on
title('8th Degree Polyfit')
xlabel('x')
ylabel('y')
plot(x,pu_2)
plot(x,pl_2)
xlim([0,1])
ylim([-0.05 0.15])

figure
hold on
title('12th Degree Polyfit')
xlabel('x')
ylabel('y')
plot(x,pu_3)
plot(x,pl_3)
xlim([0,1])
ylim([-0.05 0.15])

figure
hold on
title('15th Degree Polyfit')
xlabel('x')
ylabel('y')
plot(x,pu_4)
plot(x,pl_4)
xlim([0,1])
ylim([-0.05 0.15])