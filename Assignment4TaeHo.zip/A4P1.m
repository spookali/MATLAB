%This script will use several operations on set matrices to aid in our
%understanding of the functions in the course ENSC 180
%Martin Yang
%Feb 9, 2018

A = [4 3 1; 3 7 -1; 1 -1 9];
B = [10 8 7; 3 -3 0; 14 1 7];
C = [1 -1; 4 7; 9 5];

%a)
a = A+B;
fprintf('The addition of A and B \n')
disp(a)

%b)
b = A*C;
fprintf('The product of A and C \n')
disp(b)

%c)
c = A';
fprintf('The transpose of A \n')
disp(c)

%d)
d = A*A';
fprintf('The product of A and the transpose of A \n')
disp(d)

%e)
e = C*C';
fprintf('The product of C and the transpose of C \n')
disp(e)

%f)
f = inv(A)*inv(B);
fprintf('The product of the inverse of A and the inverse of B \n')
disp(f)

%g)
g1 = rank(A);
g2 = rank(B);
fprintf('The ranks of A and B \n')
disp(g1)
disp(g2)

%h)
h = det(A);
fprintf('The determinant of A \n')
disp(h)

%i)
i = A\C;
fprintf('The solutions to the general system of [A]{x} = {C} \n')
disp(i)