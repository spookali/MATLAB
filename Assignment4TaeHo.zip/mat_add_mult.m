function mat_add_mult(A, B)

%This function will replace the addition and multiplication functions
%pre-defined within MatLab in an attempt to be a learning experience for
%the course ENSC 180
%EDIT
%It also finds the product of the two matrices
%Martin Yang
%Feb 9 ,2018

addition = NaN;
multiplication = NaN;

[rowsA, colsA] = size(A);
[rowsB, colsB] = size(B);

if colsA ~= colsB || rowsA ~= rowsB
    disp('The matrices cannot be added')
else
    for i = 1:rowsA
        for j = 1:colsA
            addition(i,j) = A(i,j) + B(i,j);
        end
    end
end

if colsA ~= rowsB
    disp('The matrices cannot be multiplied')
else
    for i = 1:rowsA
        for j = 1:colsB
            tempRow = A(i,:);
            tempCol = B(:,j);
            tempMult = zeros(1, length(tempRow));
            for k = 1:rowsB
                tempMult(k) = tempRow(k)*tempCol(k);
            end
            multiplication(i,j) = sum(tempMult);
        end
    end
end


fprintf('The multiplication is \n')
disp(multiplication)
fprintf('The addition is \n')
disp(addition)
return


end