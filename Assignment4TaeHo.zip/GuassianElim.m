%This script will find the solutions to a general system of form [A]{x] =
%{b} using Gaussian elimination

A = input('Enter a real square matrix');
[Arows, Acols] = size(A);
if length(Arows) ~= length(Acols)
    fprintf('Not a square matrix')
    return
end
b = input('Enter a real row or column matrix');
[brows, bcols] = size(b);
if length(brows) ~= length(Acols)
    fprintf('Matrices do not have the same size')
    return
end
rankCounter = 0;

Ab = ([A,b]);
[rows,cols] = size(Ab);
Rowcounter = 0;
for i = 1:rows
    Rowcounter = Rowcounter+1;
    if Ab(i,i) == 0
        continue
    else
        Ab(i,:) = Ab(i,:)/Ab(i,i); %First element of the first row, second element of the second row,...
       % b(i) = b(i)/A(i,i);
        for j = 1:rows
            if Rowcounter == j
                continue
            else
                %b(j) = b(j) - A(j,Rowcounter)*b(i);
                Ab(j,:) = Ab(j,:) - Ab(j,Rowcounter)*Ab(i,:);
            end
        end
    end
end

for i = 1:Arows
    for j = 1:Acols %Finding the final matrix [A] from Ab
        ANew(i,j) = Ab(i,j);
    end
    for j = 1:bcols %Finding the solutions of {x} from Ab
        solution(i,j) = Ab(i,j+Arows);
    end
end

rankCheck = any(ANew,2);
for i = 1:Acols
    if rankCheck(i) == 1
        rankCounter = rankCounter+1;
    end
end

if rankCounter == Acols
    fprintf('The solutions to the system are \n')
    disp(solution)
else
    fprintf('There are an infinite number of solutions to the system \n')
end