%This script 

A = [4 3 1; 3 7 -1; 1 -1 9];
a = 0:0.01:10;
I = eye(3);
solution = zeros(1, length(a));
j = 1;


for i = 1:length(a)
    solution(i) = det(A - a(i)*I);
end


for i = 1:length(a)-1
    if solution(i)*solution(i+1) < 0
        roots(j) = a(i);
        j = j+1;
    end
end

plot(a, solution)
fprintf('The roots of the equation are \n')
disp(roots)
title('Graph of a vs. Determinant of [A]-a[I]')
xlabel('a')
ylabel('Determinant of [A]-a[I]')