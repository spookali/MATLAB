%This script is intended to solve the question 4 of Assignment 6 of ENSC 180
% Martin Yang
% Mar 20, 2018

syms E L q y(x) I

%THis line assigns the second derivative of y as -(q*x^2)/(E*I)
eqn = diff(y,x,2) == -(q*x^2)/(E*I);
Dy = diff(y,x); %a condition
condition = [y(L)==0, Dy(L)==0]; %THe set of conditions
def = dsolve(eqn, condition); %THe main function, y(x) in question -- deflection of beam

slope = diff(def); %The derivative of the deflection

%SUbstitution of the length of beam = 2
L = 2;
deflection = subs(def);
deflection_simp = simplify(deflection);
FUNC = deflection_simp*E*I/q;


%Plots
fplot(FUNC, [0 2], 'm')
title('Graph of EIy/q0 vs L')
xlabel('Length L (m)')
ylabel('EIy/q')