%this script is intended to solve question 3 of the ENSC !80 assignment
%Martin yAng
%EWHATDVER DATE KEYBOARD SUCKS

syms v t Vs


%HOmogeneous solution
voltage = dsolve('D2v + 5*Dv + 6*v = Vs', 'v(0) = 10', 'Dv(0) = -2');
Vs = 0;
vh = subs(voltage);

%complete response of Vs = 8
Vs = 8;
v1 = subs(voltage);

%complete response of Vs = 3e^-4t
Vs = 3*exp(-4*t);
v2 = subs(voltage);

%THe forced response of each situation
vp1 = v1 - vh;
vp2 = v2 - vh;

%Plotting
hold on
fplot(vh, [0 10], 'm')
fplot(v1, [0 10], 'g')
fplot(v2, [0 10], ' b')
fplot(vp1, [0 10] , 'r')
fplot(vp2,[0 10],'c')
ylim([-0.5 15])
ylabel('Voltage V (V)')
title('Graph of Voltage vs Time of a Differential Equation')
xlabel('Time t (s)')
legend('Homogeneous','V = 8', 'V = 3e^-4t','Forced of 8V','Forced of 3e^-4t')
figure
fplot(vh, [0 10], 'm')