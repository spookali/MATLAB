%This script tries to solve question 5c of assignment 6 of ensc 180
%Martin yang
%March 21, 2018


%aNgle of divergence and number of seeds
d1 = 137.51;
d2 = 137.45;
d3 = 137.92;
n = 1000;

for i = 1:n
    seedradius1(i) = sqrt(i);
    seedangle1(i) = pi*d1*i/180;
    seedradius2(i) = sqrt(i);
    seedangle2(i) = pi*d2*i/180;
    seedradius3(i) = sqrt(i);
    seedangle3(i) = pi*d3*i/180;
end

figure
polarscatter(seedangle1, seedradius1)
title('Plot of 1000 seeds to 137.51 degrees divergence angle')

figure
polarscatter(seedangle2, seedradius2)
title('Plot of 1000 seeds to 137.45 degrees divergence angle')

figure
polarscatter(seedangle3, seedradius3)
title('Plot of 1000 seeds to 137.92 degrees divergence angle')
