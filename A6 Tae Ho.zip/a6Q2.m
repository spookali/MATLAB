%This script plots the function of natural response of a RLC circuit
%eNSC !80
%Martin YAng
%march 19 2018
%part A

syms v Vs
R = 2/3;
L = 1;
C = 1/2;


%Set the Vs/LC to zero because all we want is the homogeneous solution or
%trend of the function, the particular is just a constant
voltage = dsolve('D2v + (R/L)*Dv + v/(L*C) = 0', 'v(0) = 10', 'Dv(0) = 2');

%Substitutions and plots of R = 1/2
volt = subs(voltage);
hold on
fplot(volt, [0, 10])
ylim auto
title('Variation of voltage over time: part A')
xlabel('Time t (s)')
ylabel('Voltage V (V)')

%sEcond part where R = 3
R = 3;
L = 1;
C = 1/2;

volt1 = subs(voltage);
fplot(volt1, [0, 10])
legend('R1','R2')