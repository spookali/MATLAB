%This script will solve 5b
%March 20, 2018

x = 0;
y = 0;

for i = 1:1000
    x(i+1) = y(i)*(1 + sin(0.7*x(i))) - 1.2*sqrt(abs(x(i)));
    y(i+1) = 0.21-x(i);
end
plot(x,y, '.')
title('Fractal Plot of 1000 points')
xlabel('X position')
ylabel('Y position')