%This script is to solve question 5a of ENSC 180 ASSIGNMENT 6
%Martin Yang
%March 20, 2018

%Symbols
syms x y
T = 80*y.^2*exp(-x.^2-0.3*y.^2);

%PLotting
figure

fsurf(T, [-2.2 2.2 -6 6])
title('3D Contour Graph of the Temperature differential over a surface')
xlabel('Length W (m)')
ylabel('Length L (m)')
zlabel('Temperature T (K C)')
figure

fcontour(T, [-2.2 2.2 -6 6])
title('2D Graph of the Temperature differential over a surface')
xlabel('Length W (m)')
ylabel('Length L (m)')