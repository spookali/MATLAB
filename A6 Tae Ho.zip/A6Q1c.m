%Part c of question 1
%MArtin Yang
% ENSc 180
% mY shift key sucks

syms T

format shortG

%Initializations of functions
height = -0.12*T^4 + 12*T^3 - 380*T^2 + 4100*T + 220;
velocity = diff(height);
acceleration = diff(velocity);


%FInding where the velocity is zero to find the minimums and maximums of
%the height function
vel = sym2poly(velocity);
veltimes = roots(vel);

%Finding the height values where it is minimum and maximum
for i = 1:length(veltimes)
    tempAlts(i) = subs(height, T, veltimes(i));
end

%maximum height is what we want
maxAlt = double(max(tempAlts));

%finding the times where the height function is zero -- there are imaginary
%roots!
hei = sym2poly(height);
heitimes = (roots(hei));

%Counter to work around unneccesary indices of my roots vector, zerotimes
counter = 0;

%Finding real roots
for i = 1:length(heitimes)
    if imag(heitimes(i)) == 0 && real(heitimes(i)) > 0
        counter = counter+1;
        zerotimes(counter) = real(heitimes(i));
    end
end

%Ground time is the FIRST time it hits the ground, made for general
%functions of height where it may cross the x-axis multiple times after the
%origin
groundtime = min(zerotimes);

%Displays
disp('The maximum height of the balloon is')
disp(maxAlt)
disp('The time when the balloon hits the ground is')
disp(groundtime)

%plots
LIMS = [0, groundtime];
hold on
fplot(height, LIMS)
fplot(velocity, LIMS)
fplot(acceleration, LIMS)
xlabel('Time')
ylabel('Height, Velocity, Acceleration')
title('Graph of Height, Velocity, and Acceleration vs Time')
legend('Height', 'Velocity', 'Acceleration')