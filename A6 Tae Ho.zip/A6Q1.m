%This script is used to solve the homework questions from ENSC 180

syms x y 
f1 = 6*x^3 + 19*x^2 - 19*x + 4;
f2 = (x^2 - 5*x + 6)/(x^2 - 4);

a = f1*f2;
b = f1/f2;
c = a^2;

%factoring f1 and f2
f1factor = factor(f1)
f2factor = factor(f2)

%automatic simplification by matlab
disp('Simplified f1f2')
disp(simplify(a))
disp('Simplified f1/f2')
disp(simplify(b))
disp('Simplified (f1f2)^2')
disp(simplify(c))

%Part B
%First and second derivatives of f1 and f2
derivf1_1 = diff(f1)
derivf1_2 = diff(derivf1_1)
derivf2_1 = diff(f2)
derivf2_2 = diff(derivf1_1)

%Integration of f1 and f2 from 2 to 4
intf1 = int(f1, 2, 4)
intf2 = int(f2, 2, 4)