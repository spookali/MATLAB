%This script is from question 3 of assignment 5 of ENSc 180
% Martin Yang
% Mar 7 2018

syms t
height = -4.9*t^2 + 125*t + 500;
velocity = diff(height);
acceleration = diff(velocity);
figure
hold on
title('Graph of Height, Velocity, Acceleration vs. Time');
fplot(height,[0 30])
fplot(velocity, [0 30])
fplot(acceleration, [0 30])
timeGround = double(solve(height, t));

for i = 1:length(timeGround)
    if timeGround(i) > 0
        truTime = timeGround(i);
    end
end

fprintf('The time to reach the ground is %d \n', truTime)