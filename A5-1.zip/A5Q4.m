%Whatever

x = input('Enter the first term of the sequence ');
y = input('Enter the second term of the sequence ');
n = input('Enter the total number of terms in the sequence ');


fibSequence = size(1,n);
fibSequence(1) = x;
fibSequence(2) = y;
for i = 1:n-2
    fibSequence(i+2) = fibSequence(i)+fibSequence(i+1);
end
figure
polarplot(1:n,fibSequence, 'g')
title('Graph of Fibonacci Sequence vs. number of terms')