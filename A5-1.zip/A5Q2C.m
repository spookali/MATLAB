%Assignment 5 2 c
%Modified from Q2 B

%This script is to find properties of MAGIC MATRICES
% Martin Yang
% ENSC 180
% Mar, 5, 2018

A = magic(6);
B = [A 2*A; A^2 A+2];


rowSum = sum(B);
colSum = sum(B');
diagSum = sum(diag(B));

disp('The sums of the rows are')
disp(rowSum)
disp('The sums of the columns are')
disp(colSum)
disp('The sum of the diagonal is')
disp(diagSum)
