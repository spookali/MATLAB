%This script will receive an input of a Real 3x3 matrix and calculate the
%eigenvalues and eigenvectors of it.
% ONLY FOR 3X3 MATRICES
% Martin Yang
% ENSC 180
% Mar 2, 2018
% P(l) = det(A-lI)
% Mar 7, 2018 MODIFIED TO FIT THE CONDITIONS OF QUESTION NUMBER 2 A

A = input('Please enter a real 3x3 matrix');
I = [1 0 0; 0 2 0; 0 0 3];
syms l
solutionMatrix = A-l*l*I;

for i = 1:3
    for j = 1:2
        for k = 1:2
            temp1(j,k) = solutionMatrix(j+1,k+1);
            if k == 1
                temp2(j,k) = solutionMatrix(j+1, k);
            else
                temp2(j,k) = solutionMatrix(j+1, k+1);
            end
            temp3(j,k) = solutionMatrix(j+1, k);
        end
    end
end


%Finding the determinants of the cofactors of A-L*I
detTemp1 = temp1(1,1)*temp1(2,2)-temp1(1,2)*temp1(2,1);
detTemp2 = temp2(1,1)*temp2(2,2)-temp2(1,2)*temp2(2,1);
detTemp3 = temp3(1,1)*temp3(2,2)-temp3(1,2)*temp3(2,1);
% 
detSolution = solutionMatrix(1,1)*detTemp1 - solutionMatrix(1,2)*detTemp2 + solutionMatrix(1,3)*detTemp3;
eigSolutions = sym2poly(detSolution);
eigRoots = roots(eigSolutions);
%disp(eigRoots)

eigVecStore = zeros(3,3,length(eigRoots)); %Create a 3D array to hold the multiple pre-solved eigenvectors
for i = 1:size(eigRoots)
    eigVecStore(:,:,i) = A-eigRoots(i)*I;
end

for k = 1:3
    for i = 1:2
        for j = 1:3
            tempEig(i,j,k) = eigVecStore(i,j,k);
        end
    end
end

tempEig(:,3,:) = tempEig(:,3,:)*-1;

%Finding the eigenvectors
for k = 1:3 %widths
    rowCounter = 0;
    for i = 1:2
        rowCounter = rowCounter + 1;
        if tempEig(i,i,k) == 0
            continue
        else
            tempEig(i,:,k) = tempEig(i,:,k)/tempEig(i,i,k);
            for j = 1:2
                if rowCounter == j
                    continue
                else
                    tempEig(j,:,k) = tempEig(j,:,k) - tempEig(j,rowCounter,k)*tempEig(i,:,k);
                end
            end
        end
    end
end

eigVectors = zeros(1,3,3);
%extracting the values x1 and x2 from tempEig
for i = 1:2
    for k = 1:3
        eigVectors(1,i,k) = tempEig(i,3,k);
    end
end

%setting x3 to 1s
for i = 1:3
    eigVectors(1,3,i) = 1;
end

%normalize the eigenvectors
for i = 1:3
    normalizedTemp(i) = sqrt(eigVectors(1,1,i)^2 + eigVectors(1,2,i)^2 + eigVectors(1,3,i)^2);
end

for i = 1:3
    eigVectors(:,:,i) = eigVectors(:,:,i)/normalizedTemp(i);
end

for i = 1:3
    fprintf('The first eigenvalue is %i and the eigenvector is \n', eigRoots(i))
    disp(eigVectors(:,:,i))
end