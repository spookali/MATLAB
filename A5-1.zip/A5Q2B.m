%This script is to find properties of MAGIC MATRICES
% Martin Yang
% ENSC 180
% Mar, 5, 2018

A = magic(6);


rowSum = sum(A);
colSum = sum(A');
diagSum = sum(diag(A));

disp('The sums of the rows are')
disp(rowSum)
disp('The sums of the columns are')
disp(colSum)
disp('The sum of the diagonal is')
disp(diagSum)
